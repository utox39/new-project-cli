import unittest

from unittest.mock import patch

from src.newproject.newproject import Check, NewProject


class TestCheck:
    def test_config_file_validator_valid(self):
        ...

    def test_config_file_validator_invalid(self):
        ...

    def test_dev_dir_check_exists(self):
        ...

    def test_dev_dir_check_not_exists(self):
        ...


class TestNewProject:
    ...
